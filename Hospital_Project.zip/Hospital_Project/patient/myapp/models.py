from django.db import models

# Create your models here.
class patient(models.Model):
    fullname=models.CharField(max_length=20)
    email=models.CharField(max_length=20,default=0)
    dob=models.CharField(max_length=20)
    password=models.CharField(max_length=20,default=0)
    gender=models.CharField(max_length=20)
    Age=models.CharField(max_length=20)
    Height=models.CharField(max_length=20)
    weight=models.CharField(max_length=20)