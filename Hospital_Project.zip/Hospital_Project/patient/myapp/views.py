from django.shortcuts import render,HttpResponse,redirect

# Create your views here.
def hosphome(request):
    return render(request,"hosphome.html")

def patient(request):
    if request.method=="POST":
        return render(request,"patient.html")
    else:
        redirect("")




def registration(request):
    if request.method=="POST":
        return redirect("/exercise")
    else:
        return redirect(request,"hosphome.html")

def contact(request):
    return render(request,"contact.html")

def exercise(request):
    return render(request,"exercise.html")

def routines(request):
    return render(request,"routines.html")






